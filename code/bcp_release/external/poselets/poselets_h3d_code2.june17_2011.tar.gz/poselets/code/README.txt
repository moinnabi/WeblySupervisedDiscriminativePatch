This folder contains self-sufficient Matlab code to demonstrate the H3D dataset and detection using poselets.
For H3D demo please run demo_annotation_tools.m
For poselet demo please run demo_poselets.

The code is distributed with non-commercial license. Please see the associated license file.
For questions or comments please email Lubomir Bourdev at lubomir.bourdev@gmail.com

